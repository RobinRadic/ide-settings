#parse("author.php")
/**
* Part of the $author PHP packages.
*
* License and copyright information bundled with this package in the LICENSE file
 */