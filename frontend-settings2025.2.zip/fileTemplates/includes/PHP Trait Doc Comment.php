/**
 * This is the ${NAME} trait.
 *
 * @package ${NAMESPACE}
 #parse("PHP @author.php")
 */