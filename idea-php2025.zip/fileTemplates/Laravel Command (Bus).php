<?php
#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

class ${NAME} {
    public function handle(){
    
    }
}
