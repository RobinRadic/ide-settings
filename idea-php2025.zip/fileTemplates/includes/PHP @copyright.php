 #parse("author.php")
 
 * @copyright Copyright (c) ${YEAR}, $author. All rights reserved 