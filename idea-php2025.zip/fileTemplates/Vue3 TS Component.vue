<template>
    <div :class="classes" :style="styles">
        <slot></slot>
    </div>
</template>
<script lang="ts">
import { Options, Vue } from 'vue-property-decorator';
import classNames from 'classnames'

@Options({
    name: '${NAME}',
})
export default class ${NAME} extends Vue {
    get classes() { return classNames([]); } 
   
    get styles() { return {}; }
}
</script>
<style lang="scss"></style>