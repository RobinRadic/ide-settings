describe("${NAME}", () => {
    describe('When creating', ()=> {
        it('should be awesome', () => {
            expect(true).toEqual(true)
        })
    });
});
