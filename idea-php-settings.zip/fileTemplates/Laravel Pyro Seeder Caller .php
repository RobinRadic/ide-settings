<?php
#set ( $d = "$")
#if (${NAMESPACE})
namespace ${NAMESPACE};
#end
use Pyro\Platform\Database\SeedCaller;

class ${NAME} extends \Pyro\Platform\Database\Seeder
{

    use SeedCaller;
    
    public static #[[$]]#name = '${name}';
    public static #[[$]]#description = '${description}';
    public static ${d}seeds = [];
    
}