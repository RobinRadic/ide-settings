import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { CSSModules, Hot } from 'decorators';
import  classNames  from 'classnames'

const log = require('debug')('components:${NAME}')

export interface ${NAME}Props {
    /** Optional CSSProperties with nesting support */
    style?: React.CSSProperties
    /** Optional className */
    className?: string;
}

/**
 * ${NAME} component
 */
@Hot(module)
@observer
export default class ${NAME} extends Component<${NAME}Props> {
    static displayName: string     = '${NAME}'
    static defaultProps: Partial<${NAME}Props> = {}
   
    render() {
        // const {} = this.props;
        return (
            <div className={classNames(this.props.className)} style={this.props.style}>
                Hello ${NAME} !
            </div>
        )
    }
}