<?php
#set ( $d = "$")
#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

use Anomaly\Streams\Platform\Http\Controller\AdminController;


class ${NAME} extends AdminController
{

}
