<?php
##parse("PHP File Header.php")
#if (${PACKAGE_NAME})
#set( $ns = $PACKAGE_NAME.replace(".", '\') )
namespace ${ns};
#end

use Illuminate\Console\Command;

class ${NAME} extends Command {
    protected #[[$]]#signature = '${SIGNATURE}';
    protected #[[$]]#description = '${DESCRIPTION}';
    
    public function handle(){
    
    }
}