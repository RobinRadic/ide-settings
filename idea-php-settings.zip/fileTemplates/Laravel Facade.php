<?php
#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

use Illuminate\Support\Facades\Facade;

class ${NAME} extends Facade {

    protected static function getFacadeAccessor()
    {
        return ${ACCESSOR};
    }
}