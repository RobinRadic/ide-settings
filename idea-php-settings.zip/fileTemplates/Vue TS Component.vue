<template>
    <div :class="classes" :style="style">
        <slot></slot>
    </div>
</template>
<script lang="ts">
    import { Component, component, prop, Styles } from '@pyro/platform';

    @component()
    export default class ${NAME} extends Component {
        @prop.classPrefix('${NAME.toLowerCase()}') classPrefix: string

        get classes() {return { [ this.classPrefix ]: true }; }
    
        get style(): Styles { return {}; }
    }
</script>