<?php
#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

use Illuminate\Support\ServiceProvider;

class ${NAME} extends ServiceProvider
{
    public #[[$]]#providers  = [];
    
    public #[[$]]#bindings   = [];
    
    public #[[$]]#singletons = [];
    
    public function boot()
    {
        #[[$]]#this->publishes([dirname(__DIR__) . '/config/foo.php' => config_path('foo.php')]);
    }
    
    public function register()
    {
        #[[$]]#this->mergeConfigFrom(dirname(__DIR__) . '/config/foo.php', 'foo');
    }
}
