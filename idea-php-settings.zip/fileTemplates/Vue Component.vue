<template lang="pug">
    div
</template> 

<script lang="ts">
    import { Component, Vue } from "vue-property-decorator";

    @Component({
        name: '$NAME.replace('.','-')'
    })
    export default class $NAME.replace('-','').replace('.','') extends Vue {
        
    }
    
</script>

<style lang="scss">
    //@import "../../styles/base";
</style>