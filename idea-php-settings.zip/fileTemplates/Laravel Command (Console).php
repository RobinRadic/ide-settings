<?php
#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

use Illuminate\Console\Command;

class ${NAME} extends Command {
    protected #[[$]]#signature = '${SIGNATURE}';
    protected #[[$]]#description = '${DESCRIPTION}';
    
    public function handle(){
    
    }
}