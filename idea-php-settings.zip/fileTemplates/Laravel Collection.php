<?php
#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

use Illuminate\Support\Collection;

class ${NAME} extends Collection {
}
