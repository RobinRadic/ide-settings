<?php
#set ( $d = "$")
#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

use Illuminate\Foundation\Testing\DatabaseTransactions;
use Tests\TestCase;

/**
 * @testdox Feature > ${testDox}
 * @group   feature
 * @group   http
 * @group   ${group}
 */
class ${NAME} extends TestCase
{
    use DatabaseTransactions;

    /**
     * @testdox base url
     */
    public function testBaseUrl()
    {
        ${d}this->get('/')->assertStatus(200);
    }

}