<template lang="pug">
    include ./_base.pug
    ui-tabs(type="text")
        ui-tab(title="first")
            h4 asdf
            h6 et
            p sdf


</template>

<script>
    import example from '../mixins';
    export default {
        mixins: [example],
        name  : 'example-',
        data(){
            return {
            }
        }
    }
</script>
<style lang="scss" rel="stylesheet/scss">

</style>