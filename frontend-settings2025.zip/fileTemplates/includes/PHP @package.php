#if ($NAMESPACE.split("\\").size() > 1)
#if (${NAMESPACE}) * @package        $NAMESPACE.split("\\")[0]\\$NAMESPACE.split("\\")[1]
#end
#end