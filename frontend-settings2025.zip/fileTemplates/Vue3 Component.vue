<template>
    <div :class="classes"></div>
</template> 

<script lang="ts">
    import { defineComponent, computed } from "vue";

    export default defineComponent({
        name: '$NAME',
        props: {},
        data(){return {}},
        setup(props, ctx){
            let classes = computed((c)=>({
                //`\${this.prefix}-$NAME`: true
            }));
            return {
                classes
            };
        }
    });
    
</script>

<style lang="scss">
    //@import "../../styles/base";
</style>