<?php
##parse("PHP File Header.php")
#if (${PACKAGE_NAME})
#set( $ns = $PACKAGE_NAME.replace(".", '\') )
namespace ${ns};
#end

use SW\Foundation\Console\Command;

class ${NAME} extends Command {
    protected \$signature = '#[[$SIG$]]#';
    protected \$description = '#[[$DESC$]]#';
    
    public function handle(){
        #[[$END$]]#
    }
}