<?php
#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

use \App\ClientPortal\Eloquent\EloquentSeeder;

class ${NAME} extends EloquentSeeder
{
    public function run()
    {
    
    }
}