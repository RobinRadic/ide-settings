<?php
#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

class ${NAME} extends \Crvs\Platform\Database\Seeder
{
    public static #[[$]]#name = '${name}';
    public static #[[$]]#description = '${description}';

    public function run()
    {
    
    }
}