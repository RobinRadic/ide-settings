<?php
#set ( $d = "$")
#if (${NAMESPACE})
namespace ${NAMESPACE};
#end
#set($part = $NAME.replace('Controller',''))
use $NAMESPACE.split("\\")[0]\\$NAMESPACE.split("\\")[1]\\${part}\Contract\\$NAME.replace('Controller','Interface');
use $NAMESPACE.split("\\")[0]\\$NAMESPACE.split("\\")[1]\\${part}\Form\\$NAME.replace('Controller','FormBuilder');
use $NAMESPACE.split("\\")[0]\\$NAMESPACE.split("\\")[1]\\${part}\Table\\$NAME.replace('Controller','TableBuilder');
use Anomaly\Streams\Platform\Http\Controller\AdminController;


class ${NAME} extends AdminController
{

    public function index($NAME.replace('Controller','TableBuilder') ${d}table)
    {
        return ${d}table->render();
    }

    public function create($NAME.replace('Controller','FormBuilder') ${d}form)
    {
        return ${d}form->render();
    }

    
    public function edit($NAME.replace('Controller','FormBuilder') ${d}form, $NAME.replace('Controller','Interface') ${d}entry)
    {
        return ${d}form->render(${d}entry);
    }
}
