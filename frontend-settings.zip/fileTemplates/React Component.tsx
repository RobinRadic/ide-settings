import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { Hot } from 'decorators';

const log = require('debug')('components:${NAME}')

export interface ${NAME}Props {}

/**
 * ${NAME} component
 */
@Hot(module)
@observer
export default class ${NAME} extends Component<${NAME}Props> {
    static displayName: string     = '${NAME}'
    static defaultProps: Partial<${NAME}Props> = {}
   
    render() {
        // const {} = this.props;
        return (
            <div>
                Hello ${NAME} !
            </div>
        )
    }

}