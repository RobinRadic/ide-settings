/**
 * Interface ${NAME}
 *
 * @package ${NAMESPACE}
 #parse("PHP @author.php")
 */
