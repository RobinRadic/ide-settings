/**
 * This is the class ${NAME}.
 *
 * @package ${NAMESPACE}
 #parse("PHP @author.php")
 */
